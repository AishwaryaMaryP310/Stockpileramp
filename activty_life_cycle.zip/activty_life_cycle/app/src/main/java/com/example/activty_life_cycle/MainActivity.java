package com.example.activty_life_cycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    String msg="MSRIT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(msg,"The onCreate Event");
    }
    @Override
    protected void onStart(){
        super.onStart();
        Log.d(msg,"The onStart Event");
    }
    @Override
    protected void onResume(){
        super.onResume();
        Log.d(msg,"The onResume Event");
    }
    @Override
    protected void onStop(){
        super.onStop();
        Log.d(msg,"The onStop Event");
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(msg,"The onDestroy Event");
    }
}